package kr.co.terms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TermsApplicationTests {

	@Test
	void contextLoads() {
	}

}
