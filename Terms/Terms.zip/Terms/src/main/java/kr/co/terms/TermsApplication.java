package kr.co.terms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TermsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TermsApplication.class, args);
	}

}
